module.exports = {
    'secret': 'supersecret'
  };